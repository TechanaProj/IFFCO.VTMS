﻿namespace IFFCO.VTMS.Web.Models
{
    public class ChartModel
    {

        public string MonthYear { get; set; }
        public int Enrolled { get; set; }
        public int Rejected { get; set; }
    }
}
