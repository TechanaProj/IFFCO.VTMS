﻿using IFFCO.HRMS.Repository.Pattern.Core;
using System;
using System.Collections.Generic;

namespace IFFCO.VTMS.Web.Models
{
    public partial class VtmsVtReview :Entity
    {
        public string VtCode { get; set; }
        public decimal? UnitCode { get; set; }
        public string VtevaL0001 { get; set; }
        public string VtevaL0002 { get; set; }
        public string VtevaL0003 { get; set; }
        public string VtevaL0004 { get; set; }
        public string VtevaL0005 { get; set; }
        public string VtevaL0006 { get; set; }
        public string VtevaL0007 { get; set; }
        public string VtevaL0008 { get; set; }
        public string VtevaL0009 { get; set; }
        public string VtevaL0010 { get; set; }
        public string VtevaL0011 { get; set; }
        public string VtevaL0012 { get; set; }
        public string VtevaL0013 { get; set; }
        public string VtevaL0014 { get; set; }
        public string VtevaL0015 { get; set; }
        public string VtevaL0016 { get; set; }
        public string VtevaL0017 { get; set; }
        public string VtevaL0018 { get; set; }
        public string VtevaL0019 { get; set; }
        public double? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public double? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }
}
