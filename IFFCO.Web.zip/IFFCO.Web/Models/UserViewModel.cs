﻿using IFFCO.HRMS.Shared.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IFFCO.VTMS.Web.Models
{
    public class UserViewModel
    {
       public UserLoginModel UserLoginModel { get; set; }
    }
}
